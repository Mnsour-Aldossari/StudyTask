@echo off
"%~dp0runtime\bin\javaw.exe" -cp "%~dp0studytask-1.0.0.jar;%~dp0lib\*" studytask.Launcher
